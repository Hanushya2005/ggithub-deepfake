function login() {
    let username = document.getElementById('username').value.trim();
    let password = document.getElementById('password').value.trim();

    if (username === "admin" && password === "password") {
        document.getElementById('loginPage').style.display = 'none';
        document.getElementById('mainPage').style.display = 'block';
        document.querySelector('.upload-section').style.display = 'block'; // Show upload section
    } else {
        alert('Invalid credentials! Try again.');
    }
}

function analyzeFile() {
    let fileInput = document.getElementById('fileInput');
    let resultText = document.getElementById('resultText');

    if (fileInput.files.length === 0) {
        resultText.textContent = 'Please upload a file.';
        return;
    }

    let file = fileInput.files[0];
    resultText.textContent = 'Analyzing ' + file.name + '...';

    setTimeout(() => {
        resultText.textContent = 'Deepfake Detection Complete: No Deepfake Detected';
        document.querySelector('.result-section').style.display = 'block'; // Show result section
    }, 2000);
}
